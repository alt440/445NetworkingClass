This is assignment 3 of COMP445.

It has 3 important parts:
-To run the router, run the Assignment_3_tools/router/linux/router_x64 file
-To run the server, run the Request/ServerRequestRouter.java file
-To run the client, run the Request/httpfs.java file

The httpfs.java file proceeds like it did for assignment 2.
The server proceeds like it did for assignment 2, but was designed with pure Java.

First run the router, then the server, and then the client. The httpfs and ServerRequestRouter files will output the packets it received and sent to keep track of what is going on.
